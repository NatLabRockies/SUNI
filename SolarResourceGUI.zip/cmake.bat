rmdir /Q/S build
mkdir build
cd build
cmake -G "Visual Studio 17 2022" -DCMAKE_CONFIGURATION_TYPES="Debug;Release"  ..