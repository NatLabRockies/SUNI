setx SUINRELDIR C:\Projects\Github\NREL\SolarResourceGUI\SUNI
setx GTEST C:\Projects\GitHub\NREL\googletest\
setx WXMSW3 C:\wxWidgets-3.2.4
setx CMAKEBUILDDIR C:\Projects\GitHub\NREL\SolarResourceGUI\build

